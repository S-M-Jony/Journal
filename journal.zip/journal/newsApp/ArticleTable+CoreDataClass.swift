//
//  ArticleTable+CoreDataClass.swift
//  
//
//  Created by bjit on 16/1/23.
//
//

import Foundation
import CoreData

@objc(ArticleTable)
public class ArticleTable: NSManagedObject {

}
