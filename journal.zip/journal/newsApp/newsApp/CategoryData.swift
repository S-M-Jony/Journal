//
//  CategoryData.swift
//  newsApp
//
//  Created by bjit on 13/1/23.
//

import Foundation

var category = ["business","entertainment","general","health","science","sports","technology"]
