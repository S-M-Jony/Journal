//
//  CategoryCollectionViewCell.swift
//  newsApp
//
//  Created by bjit on 13/1/23.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var categoryType: UILabel!
    
}
